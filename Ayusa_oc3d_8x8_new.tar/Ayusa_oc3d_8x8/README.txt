Ayusa ver1.0.2 -> OpenComputers 3D 打印集（8x8 方块版）
=========================================================

来源:  D:\VRChatDownload\Ayusa_ver1.0.2.zip
       -> Assets/GiltchCatLab/Ayusa/fbx/Ayusa.fbx

规模:  69 个 16^3 打印块, 合计 7655 个 shape, 最挤一块 254 个
       体素: 128 x 128 x 48 (宽 x 高 x 深), 1 体素 = 0.89 cm
       方块空间: 8 x 8 x 3, 外壳共 15988 个体素(中空, 1 层壁)

做法:  FBX -> 体素化 -> 只留可见外壳 -> 16^3 分块 -> 贪心盒子合并 -> 写 .3dm
       (Lua 表格式, 与 pig48_oc3d.zip 同写法)

配色:  逐体素采样 Unity basecolor 贴图; 每块先保住少量「强调色」(眼睛/嘴/腮红/裙边等
       小面积深色或高对比色), 剩余 shape 预算再用于主体色 —— 所以脸上有眼睛和腮红。

坐标 / 摆放指南
---------------
guide_front.png   正视坐标图: 模型 + 方块网格 + X/Y 轴, 格子里是实际打印颜色
guide_layers.png  分层摆放图: Y=0..7 每层的 X x Z 格子, 标了 #打印顺序 与 shape 数
guide_iso.png     等距 XYZ 坐标图: 三轴等比例, 直接读轴上刻度 X0..X7 / Y0..Y7 / Z0..Z2
place_list.txt    按打印顺序排好的 69 块清单
preview_face.png  脸部特写(打印配色), 用来确认五官在不在

摆放规则: 块 (X,Y,Z) 的原点 = 第 (0,0,0) 块的原点 + (X, Y, Z) 格方块。
          X 向右、Y 向上、Z 向后; 模型脸朝 -Z（从 Z 小的一侧看是正脸）。
          眼睛具体在 model_3_7_0.3dm 这一块里（该块含 #303030 等深色 shape）。

打印:  print3d /usr/share/models/Ayusa_oc3d_8x8/model_0_0_0.3dm  (逐块)
       墨盒 + 变色材料; 材料按体素体积, 墨水按 shape 数。

块清单
------
  model_0_5_0.3dm  shapes= 65  voxels=  93  q6
  model_0_5_1.3dm  shapes= 65  voxels= 102  q6
  model_0_6_0.3dm  shapes= 17  voxels=  28  q6
  model_0_6_1.3dm  shapes= 31  voxels=  43  q6
  model_1_5_0.3dm  shapes= 63  voxels= 133  q6+acc2
  model_1_5_1.3dm  shapes= 61  voxels= 200  q6
  model_1_6_0.3dm  shapes= 34  voxels=  78  q6+acc4
  model_1_6_1.3dm  shapes= 46  voxels= 128  q6+acc5
  model_2_0_0.3dm  shapes=100  voxels= 119  q6+acc7
  model_2_0_1.3dm  shapes= 65  voxels=  98  q6+acc8
  model_2_1_0.3dm  shapes= 28  voxels=  68  q6
  model_2_1_1.3dm  shapes= 57  voxels= 129  q6
  model_2_2_0.3dm  shapes= 51  voxels= 114  q6
  model_2_2_1.3dm  shapes= 29  voxels=  51  q6
  model_2_3_0.3dm  shapes=151  voxels= 349  q6+acc6
  model_2_3_1.3dm  shapes=104  voxels= 175  q6+acc7
  model_2_4_0.3dm  shapes=120  voxels= 239  q6+acc1
  model_2_4_1.3dm  shapes= 58  voxels=  88  q6+acc1
  model_2_5_0.3dm  shapes=129  voxels= 267  q6
  model_2_5_1.3dm  shapes= 94  voxels= 267  q6+acc2
  model_2_6_0.3dm  shapes= 75  voxels= 141  q6+acc5
  model_2_6_1.3dm  shapes=126  voxels= 248  q6+acc5
  model_2_7_0.3dm  shapes= 45  voxels=  61  q6
  model_2_7_1.3dm  shapes= 53  voxels=  60  q6
  model_3_0_0.3dm  shapes=247  voxels= 428  q3+acc8
  model_3_0_1.3dm  shapes=189  voxels= 306  q6+acc8
  model_3_1_0.3dm  shapes= 63  voxels= 192  q6
  model_3_1_1.3dm  shapes=134  voxels= 331  q6
  model_3_1_2.3dm  shapes= 43  voxels= 110  q6
  model_3_2_0.3dm  shapes=234  voxels= 446  q6
  model_3_2_1.3dm  shapes=195  voxels= 376  q6
  model_3_2_2.3dm  shapes= 76  voxels= 150  q6
  model_3_3_0.3dm  shapes=254  voxels= 728  k12
  model_3_3_1.3dm  shapes=232  voxels= 553  q4+acc8
  model_3_3_2.3dm  shapes= 10  voxels=  29  q6
  model_3_4_0.3dm  shapes=248  voxels= 656  k6+acc8
  model_3_4_1.3dm  shapes=253  voxels= 621  k5+acc8
  model_3_5_0.3dm  shapes=253  voxels= 619  k5
  model_3_5_1.3dm  shapes=254  voxels= 526  k10+acc8
  model_3_6_0.3dm  shapes=239  voxels= 611  k2+trim1+acc8
  model_3_6_1.3dm  shapes=249  voxels= 790  k4+trim1+acc6
  model_3_7_0.3dm  shapes=235  voxels= 511  k3+acc8
  model_3_7_1.3dm  shapes=224  voxels= 406  q4+acc5
  model_4_0_0.3dm  shapes=164  voxels= 215  q6+acc8
  model_4_0_1.3dm  shapes= 97  voxels= 163  q6+acc8
  model_4_1_0.3dm  shapes= 39  voxels= 111  q6
  model_4_1_1.3dm  shapes= 72  voxels= 171  q6
  model_4_2_0.3dm  shapes= 76  voxels= 168  q6
  model_4_2_1.3dm  shapes= 64  voxels= 104  q6
  model_4_3_0.3dm  shapes=221  voxels= 423  q6+acc8
  model_4_3_1.3dm  shapes=135  voxels= 218  q6+acc6
  model_4_4_0.3dm  shapes=210  voxels= 359  q6+acc5
  model_4_4_1.3dm  shapes=100  voxels= 139  q6+acc4
  model_4_5_0.3dm  shapes=180  voxels= 335  q6+acc8
  model_4_5_1.3dm  shapes= 90  voxels= 245  q6+acc7
  model_4_6_0.3dm  shapes=114  voxels= 183  q6+acc8
  model_4_6_1.3dm  shapes=191  voxels= 317  q6+acc6
  model_4_7_0.3dm  shapes= 91  voxels= 126  q6+acc1
  model_4_7_1.3dm  shapes=109  voxels= 134  q6
  model_5_5_0.3dm  shapes= 70  voxels= 140  q6
  model_5_5_1.3dm  shapes= 91  voxels= 244  q6
  model_5_6_0.3dm  shapes= 27  voxels=  80  q6
  model_5_6_1.3dm  shapes= 29  voxels= 129  q6
  model_6_5_0.3dm  shapes= 62  voxels=  96  q6
  model_6_5_1.3dm  shapes= 66  voxels= 109  q6
  model_6_6_0.3dm  shapes= 26  voxels=  39  q6
  model_6_6_1.3dm  shapes= 21  voxels=  56  q6
  model_7_5_0.3dm  shapes=  5  voxels=   6  q6
  model_7_5_1.3dm  shapes=  6  voxels=  10  q6
