Ayusa ver1.0.2 -> OpenComputers 3D 打印集  [8x8 方块版]
=========================================================

来源:  D:\VRChatDownload\Ayusa_ver1.0.2.zip
       -> Ayusa ver1.0.2.unitypackage -> Assets/GiltchCatLab/Ayusa/fbx/Ayusa.fbx

规模:  69 个 16^3 打印块, 合计 7673 个 shape, 最挤一块 254 个
       (OpenComputers printer.maxShapes = 256 / 块, 全部达标)
       体素: 128 x 128 x 48  (宽 x 高 x 深), 1 体素 = 0.89 cm, 总计 15988 个外壳体素
       方块空间: 8 x 8 x 3  (宽 x 高 x 深)

做法:  FBX -> 体素化 -> 只留一层可见外壳(中空) -> 去掉完全被包住的体素
       -> 16^3 分块 -> 贪心盒子合并 -> 逐块配色(6..3bit 或 k-means, 受 256 shape 上限约束)
       -> 写出 .3dm (Lua 表格式, 与 pig48_oc3d.zip 同写法)

颜色:  贴图按体素尺度做 box 预降采样再采样(basecolor), tint = 0xRRGGBB,
       texture = "opencomputers:White"

摆放:  model_<X>_<Y>_<Z>.3dm 的方块原点 = 基准块 + (X, Y, Z) 格,
       X 向右, Y 向上, Z 向后; tooltip 里也写了「坐标 X,Y,Z」。

打印:  print3d /usr/share/models/Ayusa_oc3d_8x8/model_0_0_0.3dm  (逐块)
       墨盒 + 变色材料; 材料按体素体积, 墨水按 shape 数。

块清单
------
  model_0_5_0.3dm  shapes= 65  voxels=  93  q6
  model_0_5_1.3dm  shapes= 65  voxels= 102  q6
  model_0_6_0.3dm  shapes= 17  voxels=  28  q6
  model_0_6_1.3dm  shapes= 31  voxels=  43  q6
  model_1_5_0.3dm  shapes= 67  voxels= 133  q6
  model_1_5_1.3dm  shapes= 61  voxels= 200  q6
  model_1_6_0.3dm  shapes= 37  voxels=  78  q6
  model_1_6_1.3dm  shapes= 49  voxels= 128  q6
  model_2_0_0.3dm  shapes=102  voxels= 119  q6
  model_2_0_1.3dm  shapes= 73  voxels=  98  q6
  model_2_1_0.3dm  shapes= 28  voxels=  68  q6
  model_2_1_1.3dm  shapes= 57  voxels= 129  q6
  model_2_2_0.3dm  shapes= 51  voxels= 114  q6
  model_2_2_1.3dm  shapes= 29  voxels=  51  q6
  model_2_3_0.3dm  shapes=153  voxels= 349  q6
  model_2_3_1.3dm  shapes=104  voxels= 175  q6
  model_2_4_0.3dm  shapes=120  voxels= 239  q6
  model_2_4_1.3dm  shapes= 58  voxels=  88  q6
  model_2_5_0.3dm  shapes=129  voxels= 267  q6
  model_2_5_1.3dm  shapes= 96  voxels= 267  q6
  model_2_6_0.3dm  shapes= 78  voxels= 141  q6
  model_2_6_1.3dm  shapes=127  voxels= 248  q6
  model_2_7_0.3dm  shapes= 45  voxels=  61  q6
  model_2_7_1.3dm  shapes= 53  voxels=  60  q6
  model_3_0_0.3dm  shapes=245  voxels= 428  q3
  model_3_0_1.3dm  shapes=198  voxels= 306  q6
  model_3_1_0.3dm  shapes= 63  voxels= 192  q6
  model_3_1_1.3dm  shapes=134  voxels= 331  q6
  model_3_1_2.3dm  shapes= 43  voxels= 110  q6
  model_3_2_0.3dm  shapes=234  voxels= 446  q6
  model_3_2_1.3dm  shapes=195  voxels= 376  q6
  model_3_2_2.3dm  shapes= 76  voxels= 150  q6
  model_3_3_0.3dm  shapes=254  voxels= 728  k12
  model_3_3_1.3dm  shapes=232  voxels= 553  q4
  model_3_3_2.3dm  shapes= 10  voxels=  29  q6
  model_3_4_0.3dm  shapes=233  voxels= 656  k6
  model_3_4_1.3dm  shapes=242  voxels= 621  k5
  model_3_5_0.3dm  shapes=253  voxels= 619  k5
  model_3_5_1.3dm  shapes=243  voxels= 526  k12
  model_3_6_0.3dm  shapes=250  voxels= 611  k1
  model_3_6_1.3dm  shapes=239  voxels= 790  k6+trim1
  model_3_7_0.3dm  shapes=223  voxels= 511  k3
  model_3_7_1.3dm  shapes=221  voxels= 406  q4
  model_4_0_0.3dm  shapes=171  voxels= 215  q6
  model_4_0_1.3dm  shapes=100  voxels= 163  q6
  model_4_1_0.3dm  shapes= 39  voxels= 111  q6
  model_4_1_1.3dm  shapes= 72  voxels= 171  q6
  model_4_2_0.3dm  shapes= 76  voxels= 168  q6
  model_4_2_1.3dm  shapes= 64  voxels= 104  q6
  model_4_3_0.3dm  shapes=234  voxels= 423  q6
  model_4_3_1.3dm  shapes=137  voxels= 218  q6
  model_4_4_0.3dm  shapes=210  voxels= 359  q6
  model_4_4_1.3dm  shapes=100  voxels= 139  q6
  model_4_5_0.3dm  shapes=180  voxels= 335  q6
  model_4_5_1.3dm  shapes= 91  voxels= 245  q6
  model_4_6_0.3dm  shapes=121  voxels= 183  q6
  model_4_6_1.3dm  shapes=192  voxels= 317  q6
  model_4_7_0.3dm  shapes= 91  voxels= 126  q6
  model_4_7_1.3dm  shapes=109  voxels= 134  q6
  model_5_5_0.3dm  shapes= 70  voxels= 140  q6
  model_5_5_1.3dm  shapes= 91  voxels= 244  q6
  model_5_6_0.3dm  shapes= 27  voxels=  80  q6
  model_5_6_1.3dm  shapes= 29  voxels= 129  q6
  model_6_5_0.3dm  shapes= 62  voxels=  96  q6
  model_6_5_1.3dm  shapes= 66  voxels= 109  q6
  model_6_6_0.3dm  shapes= 26  voxels=  39  q6
  model_6_6_1.3dm  shapes= 21  voxels=  56  q6
  model_7_5_0.3dm  shapes=  5  voxels=   6  q6
  model_7_5_1.3dm  shapes=  6  voxels=  10  q6
